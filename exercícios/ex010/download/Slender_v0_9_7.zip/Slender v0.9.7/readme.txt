SLENDER: THE EIGHT PAGES (v0.9.7)
---------------------------------

Controls (default):

*  Mouse -- Look around
*  W,A,S & D -- Move
*  Left Shift -- Jog/Sprint
*  Left Mouse Click -- Pick up pages
*  F or Right Mouse Click -- Flashlight
*  Q & E -- Zoom in/out
*  Escape -- Pause/Quit


Tips:

*  The Slender Man can capture you if it gets too close.
*  Do not look at the Slender Man for too long, or you will lose.  The further you are, the safer it is to look.
*  Your flashlight has a limited battery; it will not drain while it is turned off.  You also can look at the
Slender Man longer while it is off.  However, having it off will make you easier to catch.
*  Jogging/sprinting causes your stamina to drop; it recovers when walking, and recovers twice as fast when 
standing still.
*  Sprinting causes your maximum stamina to drop slightly; jogging does not.



UPDATES (v0.9.7)
----------------
*  Added a subtitle to the game ("The Eight Pages") to differentiate it from future versions.
*  Improved main menu and added music to it.  Also now includes links to Slender Man info and YouTube series.
*  Added different light sources (unlocked after beating the game once).
*  Added shadows (not especially noticeable except in lit areas).
*  Your jogging speed now increases gradually as more pages are collected.
*  Removed the cooldown for stamina recovery after jogging/sprinting, and reduced the stamina drain rate.  When
you start jogging/sprinting, however, it immediately deducts 5% of your stamina.  This will allow you to jog or
sprint for a much longer period of time, but makes repeated taps of the jog/sprint button cause your stamina
to drain very quickly (effectively getting rid of a former exploit).
*  The maximum distance you can see decreases as you collect more pages; this is to keep the challenge similar
for people who have fog turned off.  For the same reason, Distance Shade can no longer be turned off.
*  Added a menu option to automatically skip the intro.
*  Added a pause feature, but you can only pause if there's no static (which prevents you from pausing the game
in response to seeing the Slender Man).
*  Fixed a bug where the flashlight would try to illuminate a page on the other side of a wall.
*  Removed one of the hidden modes (it was only a matter of time, since it contained copyrighted material).


UPDATES (v0.9.6)
----------------
*  Fog now starts out almost non-existant, and gets more dense as more pages are collected.
*  Enabled the enemy to appear more often in areas you just can't see (previously, he would avoid appearing in
areas you weren't facing, so this will allow him to appear, for example, in front of you but behind a tree).
*  Added a 1-second cooldown after jogging/sprinting before your stamina starts to recover.  Your flashlight
also swings back up in front of you a little bit slower than before.
*  Reduced the enemy's speed slightly to compensate for the above two changes.
*  Added more to the Options menu.  You can now change the mouse sensitivity, and tweak a few extra graphics
options (which should hopefully help with framerate issues).
*  Fixed a bug where the enemy would sometimes appear partially inside a wall.
*  Fixed a bug where tree leaves would light up if the flashlight was anywhere near the tree.  Also added a small
amount of wind movement on the leaves.
*  Removed "Map" button from input control list (there was never a map).


UPDATES (v0.9.5)
----------------
*  Added fog to the woods.
*  Added an option to turn the tree render distance down and turn off the aforementioned fog, for those people
who are getting framerate issues with either.
*  Flashlight now swings over to point at a nearby page when close enough to pick it up (instead of the page
highlighting).
*  The 'level' of the game (which increases as each page is collected) will raise on its own if you take too
long between collecting pages.  It does not raise again when the pages are then collected, until it catches
up to the effective level.  The effective level still maxes out at 7.
*  Added a new hidden mode that unlocks after winning the game.  You now need to beat this mode as well in
order to unlock the final hidden mode (it will need to be unlocked again for those who unlocked it in v0.9.4,
but if you beat the game once in v0.9.4, the new mode will be unlocked as well).
*  Fixed flashlight battery sometimes draining even when it is turned off (rare bug).
*  Fixed a long-standing bug where the static zooms when zooming the camera.


UPDATES (v0.9.4)
----------------
*  Scaled back the tree render distances even further than before, and added fog to obscure the distance.  The
game should in theory run a lot better now.
*  Increased jogging speed slightly, and increased its stamina drain to compensate (you still run the same
distance on the same amount of stamina, just faster).
*  Reduced the stamina boost you get from being shocked, to prevent people from using it to their advantage too
much (it was making it too easy to run from the enemy).
*  Added a main menu; currently the only option is to invert the mouse (all the other ones are set when you run
the game).
*  Modified the ending slightly to make it a LITTLE more satisfying.
*  Tweaked enemy movement slightly.


UPDATES (v0.9.3)
----------------
*  Scaled back the tree render distances by a large amount.  It's still a little higher than v0.9.1, but it is
considerably less intensive now, so that SHOULD remove the framerate issue.
*  Flashlight now points at the ground when jogging/sprinting (instead of completely off-screen like the last
update), so you can still see a LITTLE of what's ahead of you.
*  Added a flashlight key for Mac users who don't have a two-button mouse (key is F by default).  Right mouse
click still turns on and off the flahslight.
*  Added tile footstep sounds to the complex.


UPDATES (v0.9.2)
----------------

*  Completely redid sprinting system.  Now instead of sprinting, the shift key will jog, moving just a slight
bit faster than your walk speed.  You can jog for a long time, and walking/standing still will recover your
stamina.  Being shocked (when it plays the dramatic sound) allows you to sprint for about 10 seconds, moving
very quickly but draining stamina much faster.
*  Being shocked now gives you a small boost of stamina.
*  Your maximum stamina now only drops when sprinting.  Jogging does not affect maximum stamina at all.
*  Jogging/sprinting will cause you to lower your flashlight, making it harder to see what's ahead.
*  Decreased maximum vision range when flashlight is off or lowered.
*  Slightly reduced flashlight battery life again.
*  The game now allows you to start a new game when you lose, instead of automatically quitting.
*  Modified enemy's movement slightly to make it less predictable when pursuing.
*  Added an extra effect to the enemy when static builds.
*  Fixed a bug where intro/outro lights were not rendering correctly on low graphics settings.
*  Made distant trees render better.  Please let me know if this negatively affects framerate by much for you.


UPDATES (v0.9.1)
----------------

*  Turning off the flashlight reduces how fast static will build when looking at the enemy (effectively doubles
your distance for calculation purposes); also, causes the enemy's movement to be slightly more erratic (less
likely to 'jump' directly towards you)
*  Decreased battery life slightly (it should still last long enough for a full game)
*  Replaced textures on the pillars and cross-wall areas; previous textures were causing startup lag
*  Slightly increased walk/run speed, but slightly increased enemy's movement speed to compensate


CREDITS
-------

*  GAME DESIGN & PROGRAMMING
**  Mark J. Hadley


*  MUSIC & SOUND
**  Mark J. Hadley


*  MODELS
**  Pau Cano
**  Universal Image
**  Unity Technologies
**  VIS Games
**  Profi Developers


This game is copyright 2012 by Mark J. Hadley And Parsec Productions.  This is a free, non-profit game, so you
should not be charged by anyone for this.  Comments are welcome at: AgentParsec@gmail.com